import os
import pandas as pd
import matplotlib.pyplot as plt

# 設定檔案路徑
initial_model_path = '/Users/rico/Desktop/文字/ml_venv/aimidterm/msftall/predictions_epoch200_batch32.csv'
bearish_model_path = '/Users/rico/Desktop/文字/ml_venv/aimidterm/msftbearish_predictions/bearish_predictions_epoch50_batch64.csv'
bullish_model_path = '/Users/rico/Desktop/文字/ml_venv/aimidterm/msftbullish_predictions/bullish_predictions_epoch60_batch32.csv'
validation_data_path = '/Users/rico/Desktop/文字/ml_venv/aimidterm/data_set/msftvali/MSFT_financial_indicators_2024.csv'

# 加載真實驗證數據
df_val = pd.read_csv(validation_data_path)
dates = df_val['Date']
val_data = df_val['Close'].values

# 加載初始模型的預測數據
df_initial = pd.read_csv(initial_model_path)
predictions_initial = df_initial['Predicted Prices'].values

# 加載熊市專注模型的預測數據
df_bearish = pd.read_csv(bearish_model_path)
predictions_bearish = df_bearish['Predicted Prices'].values

# 加載牛市專注模型的預測數據
df_bullish = pd.read_csv(bullish_model_path)
predictions_bullish = df_bullish['Predicted Prices'].values

# 繪製圖表
plt.figure(figsize=(12, 8))

# 真實價格數據
plt.plot(dates[-len(predictions_initial):], val_data[-len(predictions_initial):], label='Actual Prices', color='black')

# 初始模型的預測數據
plt.plot(dates[-len(predictions_initial):], predictions_initial, label='Initial Model Prediction', linestyle='--', color='blue')

# 熊市專注模型的預測數據
plt.plot(dates[-len(predictions_bearish):], predictions_bearish, label='Bearish Model Prediction', linestyle='--', color='red')

# 牛市專注模型的預測數據
plt.plot(dates[-len(predictions_bullish):], predictions_bullish, label='Bullish Model Prediction', linestyle='--', color='green')

# 設定標題和標籤
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('Stock Price Prediction Comparison: Initial vs Bearish vs Bullish Models')
plt.legend()

# 儲存圖片
output_folder = 'googlecomparison'
os.makedirs(output_folder, exist_ok=True)
image_filename = os.path.join(output_folder, 'combined_predictions_comparison.png')
plt.savefig(image_filename)
plt.show()

print(f"重疊比較圖已儲存為 {image_filename}")
