import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

# Function to load data from a folder
def load_data_from_folder(folder):
    all_files = [f for f in os.listdir(folder) if f.endswith('.csv')]
    dataframes = [pd.read_csv(os.path.join(folder, file)) for file in all_files]
    df = pd.concat(dataframes, ignore_index=True)
    return df

# Load training data
train_folder = '/Users/rico/Desktop/文字/ml_venv/aimidterm/data_set/MSFT'
df_train = load_data_from_folder(train_folder)

# Load validation data
validation_folder = '/Users/rico/Desktop/文字/ml_venv/aimidterm/data_set/msftvali'
df_val = load_data_from_folder(validation_folder)

# Extract 'Close' price and additional bullish features
train_data = df_train[['Close', 'High', 'Volume']].values
val_data = df_val[['Close', 'High', 'Volume']].values

# Normalize the data
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_train_data = scaler.fit_transform(train_data)
scaled_val_data = scaler.transform(val_data)

# Set the number of time steps (n_steps)
n_steps = 60

# Create training sequences focusing on bullish indicators
X_train, y_train = [], []
for i in range(n_steps, len(scaled_train_data) - 60):
    X_train.append(scaled_train_data[i-n_steps:i, :])
    y_train.append(scaled_train_data[i, 0])  # Targeting 'Close' price as the primary output

X_train, y_train = np.array(X_train), np.array(y_train)

# Create validation sequences
X_val, y_val = [], []
for i in range(n_steps, len(scaled_val_data)):
    X_val.append(scaled_val_data[i-n_steps:i, :])

X_val = np.array(X_val)

# Build the LSTM model
model = Sequential()
model.add(LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])))
model.add(LSTM(units=50, return_sequences=False))
model.add(Dense(units=25))
model.add(Dense(units=1))

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error')

# Train the model with adjusted parameters to focus on a bullish scenario
epoch = 60  # Increased epochs to allow for better fitting
batch_size = 32  # Reduced batch size for more frequent updates
model.fit(X_train, y_train, batch_size=batch_size, epochs=epoch, validation_data=(X_val, scaled_val_data[:len(X_val), 0]))

# Predict using validation data
predictions = model.predict(X_val)
predictions = scaler.inverse_transform(np.concatenate((predictions, np.zeros((predictions.shape[0], 2))), axis=1))[:, 0]  # Rescale only 'Close' predictions

# Visualization
plt.figure(figsize=(10, 6))
plt.plot(df_val['Date'][-len(predictions):], df_val['Close'].values[-len(predictions):], label='Actual Prices')
plt.plot(df_val['Date'][-len(predictions):], predictions, label='Predicted Prices (Bullish Focus)', linestyle='--', color='green')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('Bullish Market Prediction using LSTM (Validation Data)')
plt.legend()

# Create the output folder if it doesn't exist
output_folder = 'msftbullish_predictions'
os.makedirs(output_folder, exist_ok=True)

# Save the plot with epoch and batch size info
image_filename = os.path.join(output_folder, f'bullish_predictions_epoch{epoch}_batch{batch_size}.png')
plt.savefig(image_filename)
plt.show()

print(f"牛市預測圖已儲存為 {image_filename}")

# Save predictions to a CSV file
output_df = pd.DataFrame({
    'Date': df_val['Date'][-len(predictions):], 
    'Actual Prices': df_val['Close'].values[-len(predictions):], 
    'Predicted Prices': predictions
})

# Save the CSV with epoch and batch size info
output_filename = os.path.join(output_folder, f'bullish_predictions_epoch{epoch}_batch{batch_size}.csv')
output_df.to_csv(output_filename, index=False)
print(f"牛市預測數據已儲存為 {output_filename}")
