import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# 讀取預測和實際數據的 CSV 文件
csv_file = '/Users/rico/Desktop/文字/ml_venv/aimidterm/msftall/predictions_epoch120_batch64.csv'  # 替換成你的路徑
df = pd.read_csv(csv_file)

# 提取實際值和預測值
actual = df['Actual Prices'].values
predicted = df['Predicted Prices'].values

# 計算平均絕對誤差 (MAE)
mae = mean_absolute_error(actual, predicted)
print(f"平均絕對誤差 (MAE): {mae}")

# 計算均方根誤差 (RMSE)
rmse = np.sqrt(mean_squared_error(actual, predicted))
print(f"均方根誤差 (RMSE): {rmse}")

# 計算 R平方 (R²)
r2 = r2_score(actual, predicted)
print(f"R平方 (R²): {r2}")
