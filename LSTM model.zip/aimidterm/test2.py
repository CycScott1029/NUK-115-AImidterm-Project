import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

# Function to load data from a folder
def load_data_from_folder(folder):
    all_files = [f for f in os.listdir(folder) if f.endswith('.csv')]
    dataframes = [pd.read_csv(os.path.join(folder, file)) for file in all_files]
    df = pd.concat(dataframes, ignore_index=True)
    return df

# Load training data
train_folder = '/Users/rico/Desktop/文字/ml_venv/aimidterm/data_set/MSFT'
df_train = load_data_from_folder(train_folder)

# Load validation data
validation_folder = '/Users/rico/Desktop/文字/ml_venv/aimidterm/data_set/msftvali'
df_val = load_data_from_folder(validation_folder)

# Extract the 'Close' price for both training and validation sets
train_data = df_train['Close'].values
val_data = df_val['Close'].values

# Normalize the data
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_train_data = scaler.fit_transform(train_data.reshape(-1, 1))
scaled_val_data = scaler.transform(val_data.reshape(-1, 1))

# Set the number of time steps (n_steps)
n_steps = 60

# Create training sequences
X_train, y_train = [], []
for i in range(n_steps, len(scaled_train_data) - 60):
    X_train.append(scaled_train_data[i-n_steps:i, 0])
    y_train.append(scaled_train_data[i, 0])

X_train, y_train = np.array(X_train), np.array(y_train)
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))

# Create validation sequences
X_val, y_val = [], []
for i in range(n_steps, len(scaled_val_data)):
    X_val.append(scaled_val_data[i-n_steps:i, 0])

X_val = np.array(X_val)
X_val = np.reshape(X_val, (X_val.shape[0], X_val.shape[1], 1))

# Build the LSTM model
model = Sequential()
model.add(LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], 1)))
model.add(LSTM(units=50, return_sequences=False))
model.add(Dense(units=25))
model.add(Dense(units=1))

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error')

# Train the model using both training and validation sets
epoch = 50  # number of epochs
batch_size = 8  # batch size
model.fit(X_train, y_train, batch_size=batch_size, epochs=epoch, validation_data=(X_val, scaled_val_data[:len(X_val), 0]))

# Predict using validation data
predictions = model.predict(X_val)
predictions = scaler.inverse_transform(predictions)  # Rescale predictions to original scale

# Visualization
plt.figure(figsize=(10, 6))
plt.plot(df_val['Date'][-len(predictions):], val_data[-len(predictions):], label='Actual Prices')
plt.plot(df_val['Date'][-len(predictions):], predictions, label='Predicted Prices')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('Stock Price Prediction using LSTM (Validation Data)')
plt.legend()

# Create the output folder if it doesn't exist
output_folder = 'msftall'
os.makedirs(output_folder, exist_ok=True)

# Save the plot with epoch and batch size info
image_filename = os.path.join(output_folder, f'predictions_epoch{epoch}_batch{batch_size}.png')
plt.savefig(image_filename)
plt.show()

print(f"Chart saved as {image_filename}")

# Save predictions to a CSV file
output_df = pd.DataFrame({
    'Date': df_val['Date'][-len(predictions):], 
    'Actual Prices': val_data[-len(predictions):], 
    'Predicted Prices': predictions.flatten()
})

# Save the CSV with epoch and batch size info
output_filename = os.path.join(output_folder, f'predictions_epoch{epoch}_batch{batch_size}.csv')
output_df.to_csv(output_filename, index=False)
print(f"Predictions saved to {output_filename}")
