import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

# Function to load data from a folder
def load_data_from_folder(folder):
    all_files = [f for f in os.listdir(folder) if f.endswith('.csv')]
    dataframes = [pd.read_csv(os.path.join(folder, file)) for file in all_files]
    df = pd.concat(dataframes, ignore_index=True)
    return df

# Load training and validation data
train_folder = '/Users/rico/Desktop/文字/ml_venv/NUK-115-AImidterm-Project-main/data_set/train'
validation_folder = '/Users/rico/Desktop/文字/ml_venv/NUK-115-AImidterm-Project-main/data_set/validation'
df_train = load_data_from_folder(train_folder)
df_val = load_data_from_folder(validation_folder)

# Extract and scale the 'Close' prices
train_data = df_train['Close'].values
val_data = df_val['Close'].values
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_train_data = scaler.fit_transform(train_data.reshape(-1, 1))
scaled_val_data = scaler.transform(val_data.reshape(-1, 1))

# Prepare sequences for training
n_steps = 60
X_train, y_train = [], []
for i in range(n_steps, len(scaled_train_data) - 60):
    X_train.append(scaled_train_data[i - n_steps:i, 0])
    y_train.append(scaled_train_data[i, 0])

X_train, y_train = np.array(X_train), np.array(y_train)
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))

# Prepare sequences for validation
X_val = []
for i in range(n_steps, len(scaled_val_data)):
    X_val.append(scaled_val_data[i - n_steps:i, 0])

X_val = np.array(X_val)
X_val = np.reshape(X_val, (X_val.shape[0], X_val.shape[1], 1))

# Build the LSTM model
model = Sequential([
    LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], 1)),
    LSTM(units=50, return_sequences=False),
    Dense(units=25),
    Dense(units=1)
])

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.0001), loss='mean_squared_error')

# Train the model
epochs = 100
batch_size = 64
model.fit(X_train, y_train, batch_size=batch_size, epochs=epochs, validation_data=(X_val, scaled_val_data[:len(X_val), 0]))

# Function to simulate different market scenarios
def simulate_scenario(scaled_data, scenario_type):
    if scenario_type == 'bullish':
        return scaled_data * 1.05  # Increase by 5%
    elif scenario_type == 'bearish':
        return scaled_data * 0.95  # Decrease by 5%
    else:
        return scaled_data  # No change for neutral

# Generate and visualize predictions for each scenario
scenarios = ['bullish', 'bearish', 'neutral']
plt.figure(figsize=(14, 8))
for scenario in scenarios:
    scenario_data = simulate_scenario(scaled_val_data[-len(X_val):], scenario)
    predictions = model.predict(scenario_data.reshape(-1, n_steps, 1))
    predictions = scaler.inverse_transform(predictions)
    
    plt.plot(df_val['Date'][-len(predictions):], predictions, label=f'Predicted Prices ({scenario.capitalize()} Scenario)')

# Plot actual prices for comparison
plt.plot(df_val['Date'][-len(predictions):], val_data[-len(predictions):], label='Actual Prices', color='black')

# Add plot details
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('Stock Price Prediction under Different Market Scenarios')
plt.legend()
plt.show()
